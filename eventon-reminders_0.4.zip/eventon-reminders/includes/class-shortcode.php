<?php
/**
 * Shortcode
 */

class evorm_shortcode{
	public $userroles;
	public function __construct(){
		
	}
	
}
new evorm_shortcode();