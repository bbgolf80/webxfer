<?php
/*
	Events Lists and Items Guide text
	version 0.1	
*/
echo "

<h4>How to Activate Lists & Items for a event</h4>
<p>Lists and Items is completely controlled and setup within eventON shortcode generator. Once the addon is acitvated go to the page where you want to show lists and items, open shortcode generator and follow the available shortcode options for Event Lists & Items</p>

";
?>