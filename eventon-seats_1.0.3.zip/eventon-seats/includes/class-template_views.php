<?php
/**
 * Templates for seat
 */

class EVOST_Temp{

	public function __construct(){
		add_action('evo_temp_evost_seat_map', array($this, 'seat_map'), 10);
		add_action('evo_temp_evost_cart_seats', array($this, 'cart_seats'), 10);
		add_action('evo_temp_evost_tooltips', array($this, 'tooltips'), 10);
	}

	// seat map
	function seat_map($is_admin= true){
		?>
			{{#each sections}}
			<span id='evost_section_{{@key}}' class='evost_section turn{{ang}} align_{{align}} type_{{type}} {{avail type capacity}} {{#if shape}}shape_{{shape}}{{/if}}<?php echo $is_admin? 'editable':'';?>' data-id='{{@key}}' data-ang='{{ang}}' data-index='{{section_index}}' data-name='{{section_name}}' tip='{{section_name}}' style='top:{{top}}px; left:{{left}}px; background-color:#{{bgc}}; {{#ifCond bgcA '==' 'yes'}}background-color:transparent;{{/ifCond}} {{#ifCond brd '==' 'yes'}}border:none;{{/ifCond}} {{#if h}}height:{{h}}px;{{/if}} {{#if w}}width:{{w}}px{{/if}}'>
				<u style='color:#{{fc}}'>{{section_name}}
					{{#ifCond type "==" "aoi"}}
						{{#if icon}}
						<i class='fa {{icon}}'></i>
						{{/if}}
					{{/ifCond}}
				</u>
				
				{{#ifCond type "==" "def"}}
				{{#each rows}}
					<span class='evost_row' data-id='{{@key}}' data-index='{{row_index}}'>
						{{#each seats}}
							<span class='evost_seat seat {{status}} {{#ifCond handicap "==" "yes"}}hand{{/ifCond}}' data-id='{{id}}' data-sid='{{Par ../../this ../this @key}}' data-number='{{number}}'></span>
						{{/each}}
					</span>
				{{/each}}
				{{/ifCond}}
			</span>
			{{/each}}
		<?php
	}

	// seats in cart on eventcard
	function cart_seats(){
		?>
		{{#ifCond total_seats '>=' 1}}
		<p class="evost_tix_title"><?php evo_lang_e('Your Tickets In Cart');?></p>				
		<ul>
		{{#each seat}}
			<li id='{{@key}}' data-seat_slug='{{seat_slug}}' data-qty='{{seat_qty}}'>
				<span class="evost_remove_tix">x</span>
				<div class="evost_tix_stub_content" style="display:block">
					<div class="evost_tt_content">
						<div class="evost_ttc_data section">
							<span class="label"><?php evo_lang_e('SEC');?></span>
							<span class="value sectionvalue">{{section}}</span></div>
						{{#ifCond seat_type "==" "seat"}}
							<div class="evost_ttc_data row">
								<span class="label"><?php evo_lang_e('ROW');?></span>
								<span class="value rowvalue">{{row}}</span></div>
							<div class="evost_ttc_data seat">
								<span class="label"><?php evo_lang_e('SEAT');?></span>
								<span class="value seatvalue">{{seat_number}}</span>
							</div>
						{{/ifCond}}
					</div>
					{{#ifCond seat_type "==" "unaseat"}}
						<div class="evost_tt_content unaseat_qty">
							<span><?php evo_lang_e('Number of Seats');?></span>
							<span>x {{seat_qty}}</span>
						</div>	
					{{/ifCond}}
					{{#each otherdata}}
						<div class="evost_tt_data otherdata {{@key}}">
							<span class="label">{{label}}</span><span class="price">{{price}}</span>
						</div>
					{{/each}}
					<div class="evost_tt_data {{#if totalprice}}hastotal{{/if}}">
						<span class="label"><?php evo_lang_e('Ticket Price');?></span><span class="price">{{price}}</span>
					</div>
					{{#if totalprice}}
					<div class="evost_tt_data totalprice">
						<span class="label"><?php evo_lang_e('Total Price');?></span><span class="price">{{totalprice}}</span>
					</div>
					{{/if}}
				</div>
			</li>
		{{/each}}
		</ul>
		<div class='evost_cart_expirations'>
			<span data-s='{{exp_time_s}}'><?php evo_lang_e('Your seats will expire in');?> <b>{{exp_time}}</b></span>
		</div>		
		<div class="evost_stub_action">
			<span class='count'>{{total_seats}} <?php echo evo_lang('Seats');?></span>
			<span class="action"><a class="evcal_btn" href='<?php echo wc_get_cart_url() ;?>'><?php evo_lang_e('Buy Now');?></a></span>
		</div>
		{{/ifCond}}
		<?php
	}

	// tool tips
	function tooltips(){
		?>
		<div class="evost_tt_content">
			<div class="evost_ttc_data section"><span class="label"><?php evo_lang_e('SEC');?></span><span class="value sectionvalue">{{section}}</span></div>
			<div class="evost_ttc_data row"><span class="label"><?php evo_lang_e('ROW');?></span><span class="value rowvalue">{{row}}</span></div>
			<div class="evost_ttc_data seat"><span class="label"><?php evo_lang_e('SEAT');?></span><span class="value seatvalue">{{seat}}</span></div>
		</div>
		{{#ifCond type '==' 'seat'}}
		<div class="evost_section_information">
			<span>{{section_name}}</span>
			{{#ifCond hand '==' true}}
			<span class="icon"><i class="fa fa-wheelchair"></i></span>
			{{/ifCond}}
		</div>
		{{/ifCond}}

		{{#ifCond type '==' 'unaseat'}}
		<div class="evost_section_information_2"><span><?php evo_lang_e('Seats available');?></span><span>{{available}}</span></div>
		{{/ifCond}}

		{{#ifCond canbuy '==' true}}
		<div class="evost_tt_data">
			<span class="label"><?php evo_lang_e('Ticket Price');?></span><span class="price">{{price}}</span>
		</div>
		{{/ifCond}}
		<?php
	}
}
new EVOST_Temp();