<?php
/**
 * Email template for unsubscribe email
 * 
 * You can edit this template by copying this file to 
 * ../wp-content/themes/yourtheme/eventon/subscriber/
 *
 * @version  0.1
 */	
	
?>
<p><?php evo_lang_e('You have been successfully unsubscribed from our site');?></p>
<p><?php evo_lang_e('Thank you!');?></p>