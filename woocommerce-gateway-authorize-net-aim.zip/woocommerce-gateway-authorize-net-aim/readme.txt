=== WooCommerce Authorize.Net AIM Gateway ===
Author: skyverge, woocommerce
Tags: woocommerce
Requires PHP: 5.6
Requires at least: 4.4
Tested up to: 4.9.8

Accept Credit Cards and eChecks via Authorize.Net AIM in your WooCommerce store

See http://docs.woothemes.com/document/authorize-net-aim/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-gateway-authorize-net-aim' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
