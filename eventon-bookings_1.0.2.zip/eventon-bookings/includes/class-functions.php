<?php
/**
 * Admin Functions
 * @version 0.1
 */

class evobo_fnc{


}