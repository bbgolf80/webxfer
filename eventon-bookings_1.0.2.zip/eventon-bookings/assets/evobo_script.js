/**
 * frontend script 
 * @version 0.1
 */
jQuery(document).ready(function($){

    // load booking cal for ajax loaded events 
    $( document ).ajaxComplete(function(event, xhr, settings) {
                        
        var data = settings.data;
        if( data.indexOf('action=the_ajax_hook') != -1){                        
            
            load_evobo_calendar();
        }
    });

    load_evobo_calendar();

    function load_evobo_calendar(){
        if($('body').find('.evobo_slots').length>0){
            S = $('body').find('.evobo_slots');
            C = S.siblings('.evobo_calendar');
            B = S.closest('.evobo_booking_section');
            
            otherData = S.data('json');
            OD = {};
            OD['hasslots'] = otherData;

           // console.log(otherData);

            draw_calendar(C, OD);
        }
    }

// Click on time slot
    $('body').on('click','.evobo_slot_selection span',function(){
        SPAN = $(this);
        
        SPAN.parent().find('span').removeClass('select');
        SPAN.addClass('select');
        EVOROW = SPAN.closest('.evorow');

        SLOTS = EVOROW.find('.evobo_slots');
        
        var ajaxdataa = { };
            ajaxdataa['action']='evobo_get_prices';
            ajaxdataa['dataset']=  SLOTS.data('dataset');
            ajaxdataa['index']=  SPAN.data('val');

        $.ajax({
            beforeSend: function(){
                EVOROW.addClass('evoloading');
            },
            type: 'POST',
            url:evobo_ajax_obj.ajaxurl,
            data: ajaxdataa,
            dataType:'json',
            success:function(data){
                if(data.status=='good'){                        
                    EVOROW.find('.evobo_price_values').html( data.content).fadeIn();
                }else{}
            },complete:function(){
                EVOROW.removeClass('evoloading');
            }
        });
        
    });

// draw calendar
    
    // click on a calendar date
    $('body').on('click','.evoGC_date',function(event){
        B = $(this).closest('.evobo_booking_section');
        click_on_calendar_date(B, $(this).data('y'), $(this).data('m'), $(this).data('d'));
    });

    // click on month nav arrow
    $('body').on('click','.evoGC_ar',function(event, ){
        C = $(this).closest('.evoGC').parent();
        D = $(this).data('d');

        CalDATA = C.data('dataset');

        header_HTML = get_calendar_header(CalDATA, D['y'], D['m'] );
       
        S = C.siblings('.evobo_slots');
        otherData = S.data('json');
        OD = {};
        OD['hasslots'] = otherData;

        HTML = get_calendar_dates(CalDATA, OD, D['y'], D['m'] );
        C.find('.evoGC_dates').html( HTML );
        C.find('.evoGC_header').replaceWith( header_HTML );
    });

    // click on today
    $('body').on('click','.evoGC_today',function(event, ){
        C = $(this).closest('.evobo_calendar');
        S = C.siblings('.evobo_slots');
        otherData = S.data('json');
        OD = {};
        OD['hasslots'] = otherData;

        draw_calendar(C, OD);
    });


    function draw_calendar(PAR, Otherdata, month, year){

        CalDATA = $(PAR).data('dataset');
                
        HTML = '';
        
        y = (year === undefined) ? parseInt(CalDATA.cty) : parseInt(year);
        mm = (month === undefined)? parseInt(CalDATA.ctm): parseInt(month);
        m = mm -1; // 0-11
        sow = CalDATA.sow; // start of the week 0-6

        DS = new Date(y+'-'+mm+"-01");
        DE = new Date(y,mm,0);
        DEc = DE.getDate();

        HTML += "<div class='evoGC'>";
        
        // calendar header
        HTML += get_calendar_header(CalDATA, y, mm );

        // Day of week
            HTML += '<span class="evoGC_days">';
            for(i=0; i<7; i++){
                sow_ = parseInt(sow)+i;
                sow_ = sow_>6? sow_-7: sow_;

                HTML += "<span class='"+ sow_+"'>"+ CalDATA.d1[ sow_ ] +"</span>";
            }
            HTML += '</span>';
        
        HTML += '<span class="evoGC_dates">';       
            
            HTML += get_calendar_dates(CalDATA, Otherdata, y, mm );
            
        HTML += '</span>';
        HTML += '</div>';
        
         // header
        HTML = '<span class="evobo_section_header">'+CalDATA.t1+'</span>'+ HTML;
       
        PAR.html( HTML );

        // get booking slots for calendar
        click_on_calendar_date( PAR.parent(), CalDATA.cty, CalDATA.ctm, CalDATA.ctd);
    }

    function get_calendar_header(CalDATA, y, mm){
        HTML = '';
        m = mm-1;
        next = {};
        next['m'] = (mm+1>12? 1: mm+1);
        next['y'] = (mm+1>12? y+1: y); 

        prev = {};
        prev['m'] = (mm-1<1? 12: mm-1);
        prev['y'] = (mm-1<1? y-1: y);

        HTML += "<span class='evoGC_header'>";
            HTML += "<span class='evoGC_monthyear'>";
                HTML += "<span class='evoGC_month'>"+ CalDATA.m[mm] +"</span>";
                HTML += "<span class='evoGC_year'>"+ y +"</span>";
            HTML += '</span>';

            HTML += "<span class='evoGC_nav'>";
                today_vis = CalDATA.ctm == mm && CalDATA.cty == y? 'none':'block';
                HTML += '<span class="evoGC_today" style="display:'+today_vis+'" >'+CalDATA.t4+'</span>';
                HTML += "<span class='evoGC_prev evoGC_ar' data-d='"+ JSON.stringify(prev) +"'><i class='fa fa-angle-left'></i></span>";
                HTML += "<span class='evoGC_next evoGC_ar' data-d='"+ JSON.stringify(next) +"'><i class='fa fa-angle-right'></i></span>";
            HTML += "</span>";
        HTML += '</span>';

        return HTML;
    }

    function get_calendar_dates(CalDATA, otherData, y, mm ){
        HTML = '';
        week = 1;
        week_break = [8,15,22,29];
        HTML += '<span class="evoGC_week">';
        sow = CalDATA.sow;
        m = mm-1;

        
        for( i=1; i<= DEc; i++){
            Dthis = new Date(y,m,i);
            __d = Dthis.getDay();

            if( i == 1){

                dof_1st =  __d; // start of the week for 1st of this month
                ifd = ( dof_1st < sow)? (( 7-sow )+ dof_1st): ( dof_1st - sow);

                if(dof_1st != sow && ifd != 7 ){
                    for(b=1; b<= ifd; b++){
                        HTML += '<span class="evoGC_date blank" '+week+'></span>';
                        week++;
                    }
                }
            }

            ADDCLASS = '';
            $.each(otherData, function(index, OD){
                if( __hasVal(OD, y) && __hasVal(OD[y], mm) && __hasVal(OD[y][mm], i)){
                    ADDCLASS += index+' ';  
                }
              
            });
            
            today = ( CalDATA.cty == y && CalDATA.ctm == mm && CalDATA.ctd == i ) ? 'today':'';
            //hasSlot = ( i in thismonthSlots)? 'hasslot':'';
            HTML += '<span class="evoGC_date '+ADDCLASS+' '+today+'" data-d="'+ i +'" data-m="'+ mm +'" data-y="'+ Dthis.getFullYear()+'"><em>'+i+ '</em></span>';

            week++;

            if( $.inArray(week,week_break) >= 0 ) HTML += '</span><span class="evoGC_week">';


        }
        HTML += '</span>';

        return HTML;
    }

    // get time slots for selected calednar date
    function click_on_calendar_date(B, y, m, d){
        DATA = B.find('.evobo_slots').data('json');
        //reset 
        B.find('.evobo_price_values').hide();
        B.find('.evoGC_date').removeClass('select');
        B.find('.evoGC_date[data-d="'+d+'"]').addClass('select');
        T = B.find('.evobo_calendar').data('dataset');

        HTML = '';
        if( __hasVal(DATA,y) ){
            if( __hasVal(DATA[y],m)){

                if( __hasVal(DATA[y][m],d)){

                    HTML += '<span class="evobo_section_header">'+T.t2+'</span>';
                    HTML += "<div class='evobo_slot_selection evobo_selection_row'>";
                    $.each( DATA[y][m][d] , function(booking_index, times){
                        if(booking_index == 'day') return true;

                        HTML += '<span class="" data-val="'+times.index+'">'+times.times+'</span>';
                    });
                    HTML += '</div>';
                }
            }
        }

        if( HTML == ''){
            HTML += '<span class="evobo_section_header">'+T.t2+'</span>';
            HTML += "<div class='evobo_slot_selection evobo_selection_row'>";
            HTML += T.t3;
            HTML += '</div>';
        }

        B.find('.evobo_selections').html( HTML );
    }

    function __hasVal(obj, key){
        return obj.hasOwnProperty(key);
    }


});