<?php
/*
	Ticket Events Guide text
	version 0.1	
*/
echo "

<h4>How to Activate Ticket for event</h4>
<p>To add Ticket to each event go to each event edit page and you should find \"Event Tickets\" box where you can enable Tickets.</p>

<h4>How to Check in Attendance at the event</h4>
<p>Go to event edit page. Under Event Tickets box click \"View Attendees\". In here you can click each attendees name to check them in. Or click again to un-check them.</p>

<h4>How to Download attendees list as CSV</h4>
<p>Go to event edit page. Under Event Ticket box click \"Download Attendees CSV\".</p>

<h4>More Guide Documents</h4>
<p><a target='_blnka' href='http://docs.myeventon.com'>Online Documentation Library</a></p>

";
?>