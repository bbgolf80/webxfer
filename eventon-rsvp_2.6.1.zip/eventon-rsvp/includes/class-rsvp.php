<?php
/**
 * Evo-rsvp post type based rsvp object
 * @version 2.6
 */

class EVO_RSVP_CPT{
	public $pmv = false;
	public $rsvp_id= false;
	public function __construct($rsvp_id){

		$pt = get_post_type($rsvp_id);
		if(!$pt || $pt != 'evo-rsvp') return false;

		$this->rsvp_id = $this->ID = (int)$rsvp_id;
		$this->load_rsvp_data();
	}

	function event_id(){
		return $this->get_prop('e_id');
	}
	function repeat_interval(){
		$r = $this->get_prop('repeat_interval');
		return $r? (int)$r: 0;
	}
	function first_name(){
		return $this->get_prop('first_name');
	}
	function last_name(){
		return $this->get_prop('last_name');
	}
	function email(){
		return $this->get_prop('email');
	}
	function count(){
		return (int)$this->get_prop('count');
	}
	function get_updates(){
		$u = $this->get_prop('updates');
		return $u && $u=='yes'? true:false;
	}
	function status(){
		$st = $this->get_prop('status');
		if(!$st) return false;
		return $st;
	}
	function checkin_status(){
		$st = $this->get_prop('status');
		if(!$st) return 'check-in';
		return $st;
	}
	function get_rsvp_status(){
		$st = $this->get_prop('rsvp');
		if(!$st) return false;
		return $st;
	}
	function edit_post_link(){
		return get_admin_url().'post.php?post='.$this->rsvp_id.'&action=edit';	
	}
	public function trans_rsvp_status($lang=''){
		$status = $this->get_rsvp_status();
		if(!$status) return;

		$_sta = array(
			'y'=>array('Yes', 'evoRSL_003'),
			'n'=>array('No', 'evoRSL_005'),
			'm'=>array('Maybe', 'evoRSL_004'),
		);

		$lang = (!empty($lang))? $lang : (!empty(EVO()->lang)? EVO()->lang: 'L1');
		return EVORS()->lang($_sta[$status][1], $_sta[$status][0], $lang);
	}

	// general getters
	function get_prop($field){
		if(!$this->pmv) return false;
		if(empty($this->pmv[$field])) return false;
		if(!isset($this->pmv[$field])) return false;
		if(!isset($this->pmv[$field][0])) return maybe_unserialize($this->pmv[$field]);
		return maybe_unserialize($this->pmv[$field][0]);
	}
	// return blank if empty instead of false
	function get_prop_($field){
		$f = $this->get_prop($field);
		return $f? $f: '';
	}

	function set_prop($field, $value){
		update_post_meta( $this->rsvp_id, $field, $value);
		$this->pmv[$field] = $value; // update local value
	}
	function load_rsvp_data(){
		$this->pmv = get_post_meta($this->rsvp_id);
	}

}