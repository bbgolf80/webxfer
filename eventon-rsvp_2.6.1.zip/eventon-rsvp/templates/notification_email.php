<?php
/**
 * Notification email sent to ADMIN
 * @version 	0.3
 *
 * To Customize this template: copy and paste this file to .../wp-content/themes/--your-theme-name--/eventon/templates/email/rsvp/ folder and edit that file.
 */

	echo EVO()->get_email_part('header');

	$args = $args;

	$event_id = $args['e_id'];
	$repeat_interval = (!empty($args['repeat_interval']))? $args['repeat_interval']: '0';

	$this_event = new EVORS_Event($event_id, $repeat_interval);

	$RSVP = new EVO_RSVP_CPT($args['rsvp_id']);
	
	$evo_options = get_option('evcal_options_evcal_1');
	$evo_options_2 = EVORS()->opt2;	
	$optRS = EVORS()->evors_opt;

	$lang = (!empty($args['lang']))? $args['lang']: 'L1';	 // language version
	EVO()->lang = $lang;

	
	// location data
		$location_data = $this_event->event->get_location_data();
		if($location_data){
			$location = (!empty($location_data['name'])? $location_data['name'].' - ': null).(!empty($location_data['location_address'])? $location_data['location_address']:null);
		}

	// notification email type
		$header_text = (!empty($args['emailtype']) && $args['emailtype']=='update')? 
			EVORS()->lang('evoRSLX_010a', 'Update to RSVP From', $lang): 
			EVORS()->lang('evoRSLX_010', 'New RSVP From', $lang);

	//styles
		$__styles_date = "font-size:48px; color:#ABABAB; font-weight:bold; margin-top:5px";
		$__styles_em = "font-size:14px; font-weight:bold; text-transform:uppercase; display:block;font-style:normal";
		$__styles_button = "font-size:14px; background-color:#".( !empty($evo_options['evcal_gen_btn_bgc'])? $evo_options['evcal_gen_btn_bgc']: "237ebd")."; color:#".( !empty($evo_options['evcal_gen_btn_fc'])? $evo_options['evcal_gen_btn_fc']: "ffffff")."; padding: 5px 10px; text-decoration:none; border-radius:4px; ";
		$__styles_01 = "font-size:30px; color:#303030; font-weight:bold; text-transform:uppercase; margin-bottom:0px;  margin-top:0;";
		$__styles_02 = "font-size:18px; color:#303030; font-weight:normal; text-transform:uppercase; display:block; font-style:italic; margin: 4px 0; line-height:110%;";
		$__sty_lh = "line-height:110%;";
		$__styles_02a = "color:#afafaf; text-transform:none";
		$__styles_03 = "color:#afafaf; font-style:italic;font-size:14px; margin:0 0 10px 0;";
		$__styles_04 = "color:#303030; text-transform:uppercase; font-size:18px; font-style:italic; padding-bottom:0px; margin-bottom:0px; line-height:110%;";
		$__styles_05 = "padding-bottom:40px; ";
		$__styles_06 = "border-bottom:1px dashed #d1d1d1; padding:5px 20px";
		$__sty_td ="padding:0px;border:none";
		$__sty_m0 ="margin:0px;";
		$__sty_button ="display: inline-block;padding: 5px 10px;border: 1px solid #B7B7B7; text-decoration:none; font-style:normal; border-radius:5px;";
	
	// reused elements
		$__item_p_beg = "<p style='{$__styles_02}'><span style='{$__styles_02a}'>";
?>

<table width='100%' style='width:100%; margin:0;font-family:"open sans"'>
	<tr>
		<td style='<?php echo $__sty_td;?>'>			
			<div style="padding:20px; font-family:'open sans'">
				<p style='<?php echo $__sty_lh;?>font-size:18px; font-style:italic; margin:0; padding-bottom:10px; text-transform:uppercase'><?php echo $header_text;?></p>
				<p style='<?php echo $__styles_01.$__sty_lh;?>'><?php echo $args['last_name'].' '.$args['first_name'];?></p>
				
				<?php if($RSVP->get_prop('names')):?>
					<!-- Additional guest names -->
					<?php echo $__item_p_beg;?><?php echo evo_lang('Additional Information', $lang)?>:</span> <?php echo implode(', ', $RSVP->get_prop('names') );?></p>
				<?php endif;?>

				<!-- rsvp ID-->
				<p style='<?php echo $__styles_02;?> padding-top:15px;'><span style='<?php echo $__styles_02a;?>'><?php echo EVORS()->lang('evoRSL_007a', 'RSVP ID', $lang)?>:</span> # <?php echo $RSVP->rsvp_id;?></p>
				<!-- RSVP status -->
				<?php echo $__item_p_beg;?><?php echo EVORS()->lang('evoRSLX_001', 'RSVP Status', $lang)?>:</span> <?php echo $RSVP->trans_rsvp_status($lang);?></p>
				<!-- name-->
				<?php echo $__item_p_beg;?><?php echo EVORS()->lang('evoRSLX_008a', 'Event Name', $lang)?>:</span> <?php echo $this_event->event->get_title();?></p>
				<!-- email address-->
				<?php echo $__item_p_beg;?><?php echo EVORS()->lang('evoRSL_009', 'Email Address', $lang)?>:</span> <?php echo $RSVP->email();?></p>

				<?php if(!empty($rsvp_pmv['phone'])):?>
				<?php echo $__item_p_beg;?><?php echo EVORS()->lang('evoRSL_009a', 'Phone Number', $lang)?>:</span> <?php echo $RSVP->get_prop('phone');?></p><?php endif;?>

				<?php echo $__item_p_beg;?><?php echo EVORS()->lang('evoRSLX_003', 'Spaces', $lang)?>:</span> <?php echo $RSVP->count();?></p>
				<!-- event time -->
				<?php echo $__item_p_beg;?><?php echo EVORS()->lang('evoRSLX_008', 'Event Time', $lang)?>:</span> <?php 
				echo $this_event->event->get_formatted_smart_time($RSVP->repeat_interval());?></p>


				<?php echo $__item_p_beg;?><?php echo EVORS()->lang('evoRSLX_003a', 'Receive Updates', $lang)?>:</span> <?php echo $RSVP->get_prop('updates');?></p>
				<?php 

				//additional fields
				for($x=1; $x<= EVORS()->frontend->addFields; $x++){
					if(evo_settings_val('evors_addf'.$x, $optRS) && !empty($optRS['evors_addf'.$x.'_1'])  && $RSVP->get_prop('evors_addf'.$x.'_1') ){
						echo $__item_p_beg. $optRS['evors_addf'.$x.'_1']. ": </span>". $RSVP->get_prop('evors_addf'.$x.'_1') ."</p>";
					}
				}
				?>
			</div>
		</td>
	</tr>
	<?php
		$event_edit_link = $this_event->event->edit_post_link();
		$rsvp_edit_link = $RSVP->edit_post_link();

		if(!empty($rsvp_edit_link) && !empty($event_edit_link)):
	?>
	<tr>
		<td  style='padding:20px; text-align:left;border-top:1px dashed #d1d1d1; font-style:italic; color:#ADADAD'>				
			<p style='<?php echo $__sty_lh.$__sty_m0;?>'><a style='<?php echo $__sty_button;?>' target='_blank' href='<?php echo $rsvp_edit_link; ?>'><?php echo evo_lang( 'View RSVP', $lang)?></a>  <a style='<?php echo $__sty_button;?>' target='_blank' href='<?php  echo $event_edit_link;?>'><?php echo evo_lang( 'Edit Event', $lang)?></a></p>
		</td>
	</tr>
	<?php endif;?>
</table>
<?php
	echo EVO()->get_email_part('footer');
?>

